package com.gomar.gomar_sanidad;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;

import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class NuevaFicha extends AppCompatActivity {
    String[] fruits = {"Apple", "Banana", "Cherry", "Date", "Grape", "Kiwi", "Mango", "Pear"};
    EditText edittext = null;
    final Calendar myCalendar = Calendar.getInstance();
    private Button btn_crear;
    private Button btn_eliminar;
    private ArrayList<int[]> listaIDs = new ArrayList<int[]>();
    int componentes = 0;


    private View.OnClickListener btn_crearListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            ClickCrear();
        }
    };
    private View.OnClickListener btn_eliminarListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            ClickEliminar();
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_ficha);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

        //Creating the instance of ArrayAdapter containing list of fruit names
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.select_dialog_item, fruits);
        //Getting the instance of AutoCompleteTextView
        AutoCompleteTextView actv = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);
        actv.setThreshold(1);//will start working from first character
        actv.setAdapter(adapter);//setting the adapter data into the AutoCompleteTextView
        actv.setTextColor(Color.RED);
        edittext = (EditText) findViewById(R.id.editText8);
        updateLabel();
        btn_crear = (Button) findViewById(R.id.btn_nuevo_comp);
        btn_crear.setOnClickListener(btn_crearListener);
        btn_eliminar= (Button) findViewById(R.id.btn_elimin_comp);
        btn_eliminar.setOnClickListener(btn_eliminarListener);



        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

        };

        edittext.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(NuevaFicha.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


    }

    private void updateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        edittext.setText(sdf.format(myCalendar.getTime()));
    }

    private void ClickCrear() {
        LinearLayout layout_comp = (LinearLayout) findViewById(R.id.layout_componentes);
        layout_comp.setOrientation(LinearLayout.VERTICAL);
        LayoutParams layoutparams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);


        LayoutParams LayoutParamsview = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

        //Creating textview .
        componentes++;
        TextView textViewComp=new TextView(this);
        textViewComp.setText("Componente "+componentes);
        textViewComp.setTag("Texto"+componentes);
        AutoCompleteTextView auto_nombre = new AutoCompleteTextView(this);
        auto_nombre.setHint("Introduce el nombre del componente "+componentes);
        auto_nombre.setTag("Nombre"+componentes);
        AutoCompleteTextView auto_peso = new AutoCompleteTextView(this);
        auto_peso.setTag("Peso"+componentes);
        auto_peso.setHint("Introduce el peso del componente "+componentes);
        listaIDs.add(new int[]{textViewComp.getId(),auto_nombre.getId(),auto_peso.getId()});

        textViewComp.setLayoutParams(LayoutParamsview);
        auto_nombre.setLayoutParams(LayoutParamsview);
        auto_peso.setLayoutParams(LayoutParamsview);

        //Adding textview to linear layout using Add View function.
        layout_comp.addView(textViewComp);
        layout_comp.addView(auto_nombre);
        layout_comp.addView(auto_peso);

    }

    private void ClickEliminar() {
        if(componentes!=0)
        {
            LinearLayout layout_comp = (LinearLayout) findViewById(R.id.layout_componentes);
            layout_comp.removeView(layout_comp.findViewWithTag(("Texto"+componentes)));
            layout_comp.removeView(layout_comp.findViewWithTag(("Nombre"+componentes)));
            layout_comp.removeView(layout_comp.findViewWithTag(("Peso"+componentes)));
            componentes--;
        }

    }
}

